This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).

# Installation
You can install the application and run locally by cloning the repo or downloading the zip. Then navigate to the /react/myreads directory from the command line. Finally, with npm installed you need to only type the commands npm install and npm start. The server should start up on localhost:3000 

# ...

This application was created as part of the Udacity React Developer Nanodegree. 
